﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;

namespace NunitAssertDemo
{
    [TestFixture]
    class Program
    {

        int x;
        [SetUp]
        public void FirstMethod()
        {
            x = 10;
        }


        [Test]
        public void IsNull()
        {
            object obj = null;
            //classic syntax
            Assert.IsNull(obj);

            //Constraint syntax
            Assert.That(obj, Is.Null);
        }

        [Test]
        public void IsNotNull()
        {
            //object obj = null;
            //classic syntax
            Assert.IsNotNull(50);

            //Constraint syntax
            Assert.That(50, Is.Not.Null);
        }

        [Test]
        public void IsTrue()
        {
            //object obj = null;
            //classic syntax
            Assert.IsTrue(4 + 4 == 8);

            Assert.That(Is.Equals(2, 4));

            //Constraint syntax
            Assert.That(4 + 4 == 8, Is.True);
            Assert.That(4, Is.Not.Negative);
        }


        [Test]
        public void IsFalse()
        {
            //object obj = null;
            //classic syntax
            Assert.IsFalse(4 + 4 == 7);

            //Constraint syntax
            Assert.That(4 + 4 == 7, Is.False);
        }

        [TearDown]
        void cleanup()
        {
            x = 0;

        }

        static void Main(string[] args)
        {
        }
    }
}
