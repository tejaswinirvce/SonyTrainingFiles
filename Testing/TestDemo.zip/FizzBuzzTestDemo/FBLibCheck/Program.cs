﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using FizzBuzzTestDemo;
namespace FBLibCheck
{
    class Program
    {
        static void Main(string[] args)
        {
            for (int i = 0; i < 500; i++)
            {
                Console.WriteLine(FizzBuzzTestDemo.FizzBuzzer.Get(i));

            }
        }
    }
}
