﻿using System;
//using Microsoft.VisualStudio.TestTools.UnitTesting;
using NUnit.Framework;
using FizzBuzzTestDemo;

/// <summary>
/// FIZZBUZZ TDD Demo
/// 1. To check the numbers for Fizzbuzz logic
/// 2.Start with 1 --> 20
/// 3.If multiples of 3 are given - return -> "Fizz"
/// 4.If multiples of 5 are given - return -> "Buzz"
/// 5.If multiples of 3 & 5 are given - return -> "FizzBuzz"
/// 6.Other numbers are returned as is.
/// 7.1,2,Fizz,4,Buzz,Fizz,7,8,Fizz,Buzz,11,12,13,14,FizzBuzz,16,17,Fizz,19,Buzz
/// </summary>

namespace FBTest
{
    [TestFixture]
    public class FizzBuzzerTest
    {
        

        [Test]
        [Ignore("May be for later testing")]
        public void Given2Return2()
        {
            //AAA

            //Arrange
            int input = 2;

            //Act
            string output = FizzBuzzer.Get(input);

            //Assert
            Assert.AreEqual("2", output);
        }

        [Test]
        
        public void Given3Mul_ReturnFizz([Values(3,6,9,12,18)] int input)
        {
            //AAA

            //Arrange
            //int input ;

            //Act
            string output = FizzBuzzer.Get(input);

            //Assert
            Assert.AreEqual("Fizz",output);
        }

        [Test]
        public void Given5Mul_ReturnBuzz([Values(5,10,20)] int input)
        {
            //AAA

            //Arrange
            //int input ;

            //Act
            string output = FizzBuzzer.Get(input);

            //Assert
            Assert.AreEqual("Buzz", output);
        }

        [Test]
        public void Given3_5Mul_ReturnFizzBuzz([Values(15)] int input)
        {
            //AAA

            //Arrange
            //int input ;

            //Act
            string output = FizzBuzzer.Get(input);

            //Assert
            Assert.AreEqual("FizzBuzz", output);
        }


        [Test]
        public void Given_nondivNums_Return_Nums([Values(1,2,4,7,8,11,13,14,16,17,19)] int input)
        {
            //AAA

            //Arrange
            //int input ;

            //Act
            string output = FizzBuzzer.Get(input);

            //Assert
            Assert.AreEqual(input.ToString(), output);
        }



    }
}
