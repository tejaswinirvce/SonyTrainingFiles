﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FizzBuzzTestDemo
{
    public class FizzBuzzer
    {
        
        static void Main(string[] args)
        {
        }


        public static string Get(int input)
        {
            //refactored - clean working code
            string result = string.Empty;
            //3 multiples
              if (input % 3 == 0)
                    result += "Fizz";
            
              //5 multiples + 3&5
            if (input % 5 == 0)
                result += "Buzz";

            //for rest of the numbers
            if (string.IsNullOrEmpty(result))
                result = input.ToString();

            return result;
        }

    }
}
