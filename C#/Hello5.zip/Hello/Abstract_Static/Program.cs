using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Abstract_Static
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("From Dog..");
            dog anime = new dog();
            anime.Run();
            anime.PerformTrick();

            Console.WriteLine();

            Console.WriteLine("From GR..");
            GoldenRetriever gold = new GoldenRetriever();
            gold.PerformTrick();

            Console.WriteLine();
            Console.WriteLine("From Animals");
            Animal ani = new Animal();
            ani.Run();
            ani.eat();
            ani.hunt();
            ani.PerformTrick();

            Console.WriteLine();

            Snake.slither();

        }
    }
}
