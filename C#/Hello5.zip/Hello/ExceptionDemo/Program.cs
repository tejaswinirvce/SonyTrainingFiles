﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExceptionDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            //MyException exobj = new MyException("Custom Exception");
            //exobj.check();

            try
            {


                //array - trying to access outside the array
                int[] numarr = { 1, 2, 3, 4, 5 };
                for (int i = 0; i < 4; i++)
                {
                    Console.WriteLine(numarr[i]);
                }

                //Divide by a zero
                Console.WriteLine("Enter a number");
                int num1 = Convert.ToInt16(Console.ReadLine());

                if (num1 < 10)
                    throw new DivideByZeroException();

                
                Console.WriteLine();
            }

            catch (DivideByZeroException ex1)
            {
                Console.WriteLine("Cant divide by a zero " + ex1.HelpLink);

            }

            catch(IndexOutOfRangeException ex2)
            {
                Console.WriteLine("Trying to access outside array?! " + ex2.Message);
            }

            catch(Exception ex)
            {
                Console.WriteLine("Generic exception handler " + ex.HelpLink );
            }
        }
    }
}
