﻿using System;

namespace ExceptionDemo
{
    class MyException:Exception
    {
        public MyException(string msg):base( msg)
        {

        }

        public void check()
        { 
        try
            {
                Console.WriteLine("\nPlease enter pin no");
                string pin = Console.ReadLine();
                if (pin != "1234")
                    throw new MyException("\nInvalid pin entered");

                //inner try
                try
                {
                    Console.WriteLine("\nPlease enter Card expiry date");
                    DateTime expdt = Convert.ToDateTime(Console.ReadLine());
                    if (expdt<DateTime.Now)

                        throw new MyException("\nCard has expired");

                }
                //inner catch
                catch
                {
                    Console.WriteLine("Card error");
                }
            }
            
            //outer catch for pin validity
            catch (MyException ex)
            {
                Console.WriteLine(" Pin Exception " + ex.Message);
            }

            //generic handler
            catch(Exception ex)
            {
                Console.WriteLine("General exception will handle all other exceptions..");
            }

            finally

            {
                Console.WriteLine("All the clean up code - final wrap code is here!");

            }
        }
    }
}
