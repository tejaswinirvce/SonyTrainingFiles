using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Country.Regions.SEAsia;
using Ar = Country.Regions.AmericanRegion;

namespace Country
{
    interface IInterface
    {

    }
    namespace Regions
    {
        class MyClass
        {

        }

        namespace SEAsia
        {

            class India
            {

            }

            interface IIndia
            {

            }

            struct SIndia
            {

            }

            enum EIndia
            {

            }
            class Singapore
            {

            }

            class Thailand
            {

            }
        }

        namespace AmericanRegion
        {
            class Us
            {

            }

            class Canada
            {

            }

            class Brazil
            {

            }
        }
    

}    

}



namespace NsDemo
{
    class Program
    {
        static void Main(string[] args)
        {
       India ind = new India();
            Ar.Brazil brz = new Ar.Brazil();   
        }
    }
}
