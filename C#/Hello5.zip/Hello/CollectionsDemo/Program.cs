﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollectionsDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            //Arrlist();
            //HtDemo();
            //SLDemo();
            DictionaryCollDemo();
        }

        class MyClass
        {

        }
        public static void Arrlist()
        {
            ArrayList al = new ArrayList
            {
                "Tangled",
                400,
                10000.00,
                new MyClass()

            };

            Console.WriteLine("Movie data from AL");

            foreach (var item in al)
            {
                Console.WriteLine(item);

            }

            al.Add("Animated movie");
            al.Remove(400);
            Console.WriteLine();

            foreach (var item in al)
            {
                Console.WriteLine(item);
            }
        }

        public static void HtDemo()
        {
            //Key-value
            Hashtable ht = new Hashtable
            {
                {"M005","Frozen" },
                {"M002","Moana" },
                {"M003","Zootopia" },
                {"M001","Spiderman" },

            };

            ICollection k = ht.Keys;
            Console.WriteLine();
            Console.WriteLine("Movies by HashTable");

            foreach (string kstr in k)
            {
                Console.WriteLine(kstr + ht[kstr]);
            }

            Console.WriteLine();
            Console.WriteLine("Movies - HT From DictionaryEntry");

            foreach  (DictionaryEntry de in ht)
            {
                Console.WriteLine($"Movie Key: {de.Key} , Movie Value: {de.Value}");
            }



        }

        public static void SLDemo()
        {
            SortedList sl = new SortedList
            {
                {"S005","Frozen" },
                {"S002","Moana" },
                {"S003","Zootopia" },
                {"S001","Spiderman" },

            };

            ICollection k = sl.Keys;
            Console.WriteLine();
            Console.WriteLine("Movies by Sorted List");

            foreach (string kstr in k)
            {
                Console.WriteLine(kstr + sl[kstr]);
            }

            Console.WriteLine();
            Console.WriteLine("Sorted List using Get Methods");

            for (int i = 0; i < sl.Count; i++)
            {
                Console.WriteLine($"{sl.GetKey(i),10}{sl.GetByIndex(i),15}");
            }


        }

        public static void DictionaryCollDemo()
        {
            Dictionary<int, string> dobj = new Dictionary<int, string>
            {
                {1,"Frozen" },
                {2,"Moana" },
                {4,"Zootopia" },
                {5,"Spiderman" }

            };

            foreach (KeyValuePair<int,string> item in dobj)
            {
                Console.WriteLine("Key :" + item.Key + " " + item.Value);
            }



        }

    }
}
