﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegateDemo
{

   
    class MultiCastDel
    {
        public delegate void DispDel(string str);
        public void disp1(string s1)
        {
            Console.WriteLine("First Message " + s1);
        }

        public void disp2(string s1)
        {
            Console.WriteLine("Second Message " +s1 );
        }

        public void disp3(string s1)
        {
            Console.WriteLine("Third Message :" + s1);
        }
    }
}
