﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegateDemo
{
    class Program
    {
        public delegate int Calc(int num1, int num2);

        static void Main(string[] args)
        {
            Program pr = new Program();

            Calc add1 = new Calc(pr.add);
            Calc sub1 = new Calc(pr.sub);

            Console.WriteLine("Subtract : "+ sub1(10,20));
            Console.WriteLine("Addition : "+ add1(30,50));

            Console.WriteLine();
            Console.WriteLine("Multicast Delegate");

            MultiCastDel mc = new MultiCastDel();
            MultiCastDel.DispDel dispobjdel = null;

            dispobjdel += new MultiCastDel.DispDel(mc.disp1);
            dispobjdel += new MultiCastDel.DispDel(mc.disp2);
            dispobjdel -= new MultiCastDel.DispDel(mc.disp3);


            dispobjdel("MultiCast Delegates");






        }

        public int add(int n1,int n2)
        {
            return n1 + n2;
        }

        public int sub(int n1, int n2)
        {
            return n1 - n2;
        }

        public int prod(int n1, int n2)
        {
            return n1 * n2;
        }

        public int div(int n1, int n2)
        {
            return n1 / n2;
        }
    }
}
