using System;



namespace World
{
    class Program
    {
        static void Main(string[] args)
        {

            
            //Calculate();
            //dispemp();
            //NumOper();
            loop();
            Console.Read();

            
        }

        public static void Calculate()
        {

            string name;
            int amount, bal;
            Console.WriteLine(" Welcome to the ICICI Bank");
            Console.WriteLine("Please Enter your Name");
            name = Console.ReadLine();
            Console.WriteLine("Hi " + name);
            Console.WriteLine("How much you want to withdraw?");
            amount = Convert.ToInt32(Console.ReadLine());
            bal = 10000 + amount;

            Console.WriteLine("Hi" + name + ",Here is the " + amount + " you withdrew and here's the updated Balance " + bal);
            Console.WriteLine("Hi, {0}, Here is the {1}  you withdrew and here's the updated Balance {2}", name, amount, bal);
            Console.WriteLine($"Hi, {name}, Here is the {amount}  you withdrew and here's the updated Balance {bal}");
            
        }
        
        public static void dispemp()
        {
            string strEmpName;
            string strEmpDept;
            int intSal;
            Console.WriteLine("Enter Employee Name");
            strEmpName = Console.ReadLine();
            Console.WriteLine("Enter Employee Department");
            strEmpDept = Console.ReadLine();
            Console.WriteLine("Enter Employee Salary");
            intSal = Convert.ToInt32(Console.ReadLine());

            if (strEmpDept == "IT")
            {
                intSal = intSal + 5000;
                goto sal;

            }

            else
            {
                intSal = intSal + 3000;
            }

            Console.WriteLine("Updated Employee Salary is" + " " + intSal);
        sal:
            Console.WriteLine("Got the salary hike");
            Console.WriteLine("Employee Salary now is" + " " + intSal);

        }


        public static void NumOper()
        {

            int num1;
            int num2;
            int res;
            char oper;
            Console.WriteLine("Enter the first Number");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the second Number");
            num2 = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter your Operand");
            oper = Convert.ToChar(Console.ReadLine());

            switch (oper)
            {
                case '+':

                    res = num1 + num2;
                    Console.WriteLine("The result is " + res);
                    break;
                case '-':
                    res = num1 - num2;
                    Console.WriteLine("The Result is" + " " + res);
                    break;
                case '*':
                    res = num1 * num2;
                    Console.WriteLine("The Result is" + " " + res);
                    break;
                case '/':
                    res = num1 / num2;
                    Console.WriteLine("The Result is" + " " + res);
                    break;

                default:
                    break;
            }

        }

        public static void loop()
        {

            int i = 10;
             while (i >=  1)
            {
                i = i - 1;

                Console.WriteLine(i);

            }

            int x = 10;
            do
            {
                Console.WriteLine("inside do");

            } while (x < 10);

            int y = 0;
            for (;y < 1; )
            {
                Console.WriteLine(y);
                y++;
            }
        }

    }


}
