﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Events
{
    //I step - create delegates
    public delegate void playersuccess();
    public delegate void playerfailure();

    class Program
    {

        //II Create Events
        public event playersuccess successevt;
        public event playerfailure failurevt;

        //III Create the functions
        public void successfunc()
        {
            Console.WriteLine("You Have WON!!  - Moving to the next level!");

        }

        public void failurefunc()
        {
            Console.WriteLine("You have lost! - Game over!");
        }

        static void Main(string[] args)
        {
            Program pr = new Program();
            int i;
            Console.WriteLine("Enter the Game status??");
            i = Convert.ToInt32(Console.ReadLine());

            if(i == 1)
            {
                //IV - Association - event with delegate by subscribing
                pr.successevt += new playersuccess(pr.successfunc);

                //V - fire the event
                pr.successevt();
            }

            else
            {
                pr.failurevt += new playerfailure(pr.failurefunc);
                pr.failurevt();
            }




        }
    }
}
