﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Reflection
{
    class Program
    {
        static void Main(string[] args)
        {
            //assemblyload();
            //chktype();foe 

            MyClass c1 = new MyClass();
            c1.ActorId = 1;
            c1.ActorName = "Rajni";
            Console.WriteLine();
            Type typ = typeof(MyClass);

            foreach (PropertyInfo pr in typ.GetProperties())
            {
                string name = pr.Name;
                object val = pr.GetValue(c1, null);

                if (val is int)
                {
                    Console.WriteLine("Int :" + name + val);
                }
                if (val is string)
                {
                    Console.WriteLine("string :" + name + val);
                }

            }


        }

        public static void assemblyload()
        {
            Assembly asm = Assembly.GetExecutingAssembly();
            Type[] asmtypes = asm.GetTypes();
            foreach (Type t in asmtypes)
            {
                Console.WriteLine(t.Name);
                Console.WriteLine(t.AssemblyQualifiedName);
            }
            Console.ReadLine();
        }

        interface Inter
        {

        }
        static void chktype()
        {
            string chk = "testing";
            Console.WriteLine("Type of str :" + chk.GetType().AssemblyQualifiedName);
            Console.WriteLine(typeof(Inter).BaseType);
        }


        class MyClass
        {
            private string _ActorName;
            public int add(int num2, int num1)
            {
                return num1 + num2;
            }

            public int ActorId { get; set; }
            public string ActorName
            {
                get
                {
                    return _ActorName;
                }


                set
                {
                    _ActorName = value;

                }
            }
        }

    }
}
    
