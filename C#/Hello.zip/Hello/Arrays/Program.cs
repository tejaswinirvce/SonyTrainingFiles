using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Arrays
{
    class Program
    {
        static void Main(string[] args)
        {
            // The code provided will print ‘Hello World’ to the console.
            // Press Ctrl+F5 (or go to Debug > Start Without Debugging) to run your app.

            //Single dimension
            int[] Numbers = { 1, 2, 3, 4, 5 };
            string[] flowers = { "Rose", "Tulips", "Daisies", "Petunias", "Geraniums" };
            Console.WriteLine(flowers.Rank);
            Console.WriteLine(flowers.Length);
            Console.WriteLine(flowers.GetLowerBound(0));
            Console.WriteLine(flowers.GetUpperBound(0));


            Array.Reverse(flowers);

            for (int i = 0; i < flowers.Length; i++)
            {
                Console.WriteLine($"Flower {i+1} is : {flowers[i]} ");
            }



            //Double dimension
            int[,] dimensiontwo = { { 1, 2 }, { 3, 4 }, { 5, 6 } };

            Console.WriteLine(dimensiontwo.Rank);
            Console.WriteLine(dimensiontwo.Length);

            for (int i = 0; i < dimensiontwo.GetLength(0); i++)
            {
                for (int j = 0; j < dimensiontwo.GetLength(1); j++)
                {
                    Console.WriteLine(dimensiontwo[i, j]);
                }
            }




            Console.WriteLine("Hello World!");
            Console.ReadKey();

            // Go to http://aka.ms/dotnet-get-started-console to continue learning how to build a console app! 
        }
    }
}
