﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Abstract_Static
{
   
    interface IAnimal
    {
        void run();
        void eat();
        void hunt();

    }

    //Abstract
      partial class  Animal:IAnimal
    {
        
        public void Run()
        {
            Console.WriteLine("Animal is running");
        }

         partial void crawl();
        

        public virtual void PerformTrick()
        {

        }

        public void run()
        {
            throw new NotImplementedException();
        }
    }


    abstract class Reptiles
    {

        public void creep()
        {
            Console.WriteLine("Animal is creeping");
        }

        public virtual void PerformTrick()
        {

        }

    }



    //Sealed
    sealed class dog : Animal
    {
        public sealed override void PerformTrick()
        {
            Console.WriteLine("From PT in Dog class");
            base.Run();
        }
        
    }


    //static

     static class Snake
    {
        static string scales = "brown";

        //Property
        public static string Scales {
            get
            {
                return scales;
            }

            set {
                
                scales = value;
            }
        }

        public static void slither()
        {
            Console.WriteLine("Here i come.." + scales );
        }

    }


    class GoldenRetriever  
    {

        public void PerformTrick()
        {
            Console.WriteLine(Snake.Scales);
            Snake.Scales  = "Green";
            Console.WriteLine(Snake.Scales);

        }

       
    }
}
