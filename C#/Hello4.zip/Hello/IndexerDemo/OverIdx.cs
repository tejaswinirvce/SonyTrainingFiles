﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IndexerDemo
{
    class OverIdx
    {
        static public int arrsize = 5;
        readonly string[] shoplist = new string[arrsize];

        public OverIdx()
        {
            for (int i = 0; i < arrsize; i++)
            {
                shoplist[i] = "---";
            }
        }

        //indexer - first - param - int
        public string this[int index]
        {
            get {

                string item;
                if(index >= 0 && index <= arrsize-1)
                {
                    item = shoplist[index];
                }
                else
                {
                    item = "";
                }

                return item;

            }

            set {

                if (index >= 0 && index <= arrsize - 1)
                {

                    shoplist [index] = value;

                }

                }
            }

        public int this[string name]
        {
            get
            {
                int index = 0;
                while(index<arrsize)
                {
                    if(shoplist[index]==name)
                    {
                        return index;
                    }
                    index++;
                }
                return index;

            }
           
        }



    }
}
