﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IndexerDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            OverIdx cart = new OverIdx();
            cart[0] = "Apples";
            cart[1] = "Oranges";
            cart[2] = "Peaches";
            cart[3] = "Apricots";
            cart[4] = "Blackberries";


            for (int i = 0; i < OverIdx.arrsize; i++)
            {
                Console.WriteLine(cart[i]);
            }

            //second indexer with int as return & string as param - shopping item as param 
            Console.WriteLine("Pencils are at .." + cart["Pencils"]);

            //Iterate
            Iterate itr = new Iterate();


            Console.WriteLine("Named Iterator - Reviews");
            foreach (string str in itr.GetReviews())
            {
                Console.WriteLine(str);

            }

            Console.WriteLine();

            Console.WriteLine("Itertor - Named color enumerator");
            foreach (string col in itr.Colors())
            {
                Console.WriteLine(col);
            }

            Console.WriteLine();

            Console.WriteLine("Itertor - Named Rating enumerator");
            foreach (int rate in itr.GetRating())
            {
                Console.WriteLine(rate);
            }

            Console.WriteLine("Default - MOvie list by Get Enum");
            Console.WriteLine("Get Enumerator");
            foreach (string item in itr)
            {
                Console.WriteLine(item);
            }

            
        }
    }
}
