﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IndexerDemo
{
    class Iterate:IEnumerable
    {
        string[] Movies = { "Avatar", "Avengers", "IT 2", "Deadpool" };
        readonly string[,] reviews = new string[3, 2] { { "Good", "better" }, { "ok", "one time" }, { "best movie", "alright" } };
        readonly int[] rating = { 1, 2, 3 };

        //Named iterator
        public IEnumerable GetRating()
        {

            for (int i = 0; i < rating.Length; i++)
            {
                yield return rating[i];
            }
          

        }

        //named iterator
        public IEnumerable Colors()
        {
            yield return ("Blue");
            yield return ("Red");
            yield return ("Green");
            yield return ("Violet");

        }

        //Named Iterators
        public IEnumerable GetReviews()
        {
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 2; j++)
                {

                    yield return reviews[i, j];
                }

            }
        }

        //Default Iterator
        public IEnumerator GetEnumerator()
        {

            for (int i = 0; i < Movies.Length; i++)
            {
                yield return Movies[i];

            }
        }


    }
}
