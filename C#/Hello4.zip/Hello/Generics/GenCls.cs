﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Generics
{
    interface IInterface
    {

    }

    //Generic Class
    class GenCls<T> //where T:IInterface
    {
        //Private generic field 
        private readonly T genval;

        //Constructor Generic
        public GenCls(T val)
        {
            genval = val;

        }

        //Generic Method
        public T Display(T age)
        {
            Console.WriteLine("Your age is : " + age );
            Console.WriteLine("Parameters type: "+ typeof(T).ToString() + "Value :" + age);
            Console.WriteLine("Parameters type: " + typeof(T).ToString() + "Value :" + genval);

            return genval;
        }



    }
}
