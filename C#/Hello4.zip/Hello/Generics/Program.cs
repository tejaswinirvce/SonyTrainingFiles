﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Generics
{
    class Program
    {
        static void Main(string[] args)
        {

            //int - obj
            GenCls<int> obj1 = new GenCls<int>(10);
            Console.WriteLine(obj1.Display(25));
            Console.WriteLine();
            
            //double - obj
            GenCls<double> obj2 = new GenCls<double>(10.5);
            Console.WriteLine(obj2.Display(25.45));
            Console.WriteLine();
            
            //string - obj
            GenCls<string> obj3 = new GenCls<string>("Twenty five");
            Console.WriteLine(obj3.Display("Twenty"));



        }
    }
}
