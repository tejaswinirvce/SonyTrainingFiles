﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Abstract_Static
{
    partial class Animal
    {
         partial void crawl()
        {
            Console.WriteLine("Partial class in a new file");
        }

        public void eat()
        {
            crawl();
        }

        public void hunt()
        {

        }
    }
}
