using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classes_Struct
{

    enum colors
    {
        Violet = 1, Indigo = 2, Blue = 3, Green = 4, Yellow = 5, Orange = 6, Red = 7
    }

    class EmployeeMain
    {

        public EmployeeMain()
        {
            Console.WriteLine("From the super main constructor");
        }

        static void Main(string[] args)
        {
            Console.WriteLine("Class , Interface, Struct example");
         //   Console.WriteLine(colors.Blue);
            //Movie mov = new Movie();

            //EmpStruct empst = new EmpStruct();
            //empst.dispStruct();

            //Employee emp = new Employee();
            //Console.WriteLine(emp.empId);
            //Console.WriteLine(emp.empName);

            //Employee emp1 = new Employee(1);
            //Console.WriteLine("Using Emp constructr 2 : " + emp1.empId);

            Manager man = new Manager();
           //Console.WriteLine(man.NoEmp);
            //man.dispMan();
            man.dispEmp();

            //Developer dev = new Developer();
            //Console.WriteLine(dev.deptName);

        }
    }


    interface IEmployee
    {

         int EmpID { get; set; }
                                           //declarations of methods
        void dispEmployee();
    }


    interface IEmployee2
    {

        int EmpID { get; set; }
        //declarations of methods
        void dispEmployee();
    }


    interface IEmployee3
    {

        int EmpID { get; set; }
        //declarations of methods
        void dispEmployee();
    }


    interface IEmployee4
    {

        int EmpID { get; set; }
        //declarations of methods
        void dispEmployee();
    }

    //Structure
    struct EmpStruct:IEmployee,IEmployee2
    {
        int empstruct;

        public int EmpID { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }

        public void dispEmployee()
        {
            throw new NotImplementedException();
        }

        public void dispStruct()
        {

        }

    }


    //Parent /super
    class Employee:EmployeeMain
    {
        //Fields

       public string empName;
       public int empId;

        //Constructor - overloaded
        public Employee()
        {
            Console.WriteLine("From Employee default constr");
            empId = 1001;
            empName = "Raja";

        }
        //Parameterized Constructors
        //Function signature - depends on order,number,data type of params
        public Employee(int id)
        {
            Console.WriteLine("From Employee parameterized constr");
            empId = id;

        }

        public Employee(int id, string name)
        {
            Console.WriteLine("From Employee parameterized constr2");
            empId = id;
            empName = name;

        }

        public Employee(string name, int id)
        {

        }

        ~ Employee()
        {
            Console.WriteLine("Destructing..from Employee");
        }
        

        //functions
        public virtual void dispEmp()
        {
            Console.WriteLine("display From the Employee class");
        }

        public void dispEmployee()
        {
          
        }
    }



    //Derived class /sub/child - Inheritance
    class Manager :Employee
    {
        public string deptName;
        public int NoEmp;

        public Manager()
        {
            
            Console.WriteLine("Constructor from Manager");
        }
        
        public override void dispEmp()
        {
           // base.dispEmp();
            Console.WriteLine("Disp from Manager class");

        }

        public void dispMan()
        {
            Console.WriteLine("From Manager class");
        }

        ~ Manager()
        {
            Console.WriteLine("Destructing from manager");
        }

    }

    class Developer:Manager
    {
        ~ Developer()
        {
            Console.WriteLine("Destructing from developer");
        }
    }

    class DBAdmin
    {

    }
}
