using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Arrays
{
    class Program
    {
        static void Main(string[] args)
        {
           
            JaggedArray();
            
        }

        public static void singlearray()
        {
            //Single dimension
            int[] Numbers = { 1, 2, 3, 4, 5 };
            string[] flowers = { "Rose", "Tulips", "Daisies", "Petunias", "Geraniums" };
            Console.WriteLine(flowers.Rank);
            Console.WriteLine(flowers.Length);
            Console.WriteLine(flowers.GetLowerBound(0));
            Console.WriteLine(flowers.GetUpperBound(0));


            Array.Reverse(flowers);

            for (int i = 0; i < flowers.Length; i++)
            {
                Console.WriteLine($"Flower {i + 1} is : {flowers[i]} ");
            }


        }

        public static void twodimension()
        {
            //Double dimension
            int[,] dimensiontwo = { { 1, 2 }, { 3, 4 }, { 5, 6 } };

            Console.WriteLine(dimensiontwo.Rank);
            Console.WriteLine(dimensiontwo.Length);

            for (int i = 0; i < dimensiontwo.GetLength(0); i++)
            {
                for (int j = 0; j < dimensiontwo.GetLength(1); j++)
                {
                    Console.WriteLine(dimensiontwo[i, j]);
                }
            }



        }


        public static void JaggedArray()
        {
            //Jagged array
            int[][] jdarr1 = new int[3][];
            jdarr1[0] = new int[4];
            jdarr1[1] = new int[2];
            jdarr1[2] = new int[1];

            jdarr1[0] = new int[] { 2, 4, 6, 8 };
            jdarr1[1] = new int[] { 2, 4 };

            jdarr1[2] = new int[] { 2 };


            //JA shortcut

            int[][] jdarr2 =
        {
                new int[]{1,2,3},
                new int[]{2,4},
                new int[]{3,5,7,9}


            };


            for (int i = 0; i < jdarr2.Length; i++)
            {
                Console.Write("Row({0}): ", i + 1);

                for (int j = 0; j < jdarr2[i].Length; j++)
                {

                    Console.Write($"{jdarr2[i][j],4}");
                }

                Console.WriteLine();
            }

        }




    }
}
