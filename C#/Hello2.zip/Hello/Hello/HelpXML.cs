﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/// <summary>
/// Class about somethingm
/// <remarks>
/// Longer comments help in documenting
/// </remarks>
/// </summary>
namespace Hello
{/*
    dsytdt
    rtfutyfk
    rdfyd
    */
    

    class HelpXML
    {
        /// <summary>
        /// FOr the name property
        /// </summary>
        private string myName = null; 

        /// <summary>
        /// Method of this class
        /// <paramref name="s"/>
        /// </summary>
        /// <param name="s">this will capture the parameters</param>
        public void SomeMethod(string s)
        {

        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="args"></param>
        /// <returns></returns>
        static int Main(string[] args)
        {
            // The code provided will print ‘Hello World’ to the console.
            // Press Ctrl+F5 (or go to Debug > Start Without Debugging) to run your app.
            Console.WriteLine("Hello World!");
            Console.ReadLine();
            return 1;

        }

    }
}
