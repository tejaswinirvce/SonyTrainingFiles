﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVCFirstDemoSony.Controllers
{
    public class MusicController : Controller
    {
        // GET: Music
        public ActionResult Index()
        {
            return View();
        }

        public string hello(string name, int id)
        {
            
            return HttpUtility.HtmlEncode("The user id is : "+ id + "And Name is :" + name);
        }






    }
}