﻿using System.Web.Mvc;

namespace MVCFirstDemoSony.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "All about Movies";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "To see your fav movies - contact here..";

            return View();
        }
    }
}