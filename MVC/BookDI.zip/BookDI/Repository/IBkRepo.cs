﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookDI.Repository
{
    public interface IBkRepo
    {
        IEnumerable<Book> GetBooks();
        Book Get(int id);
        Book Add(Book item);
        bool Update(Book item);
        bool Delete(int id);
    }
}
