﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BookDI.Repository
{
    public class BookConcreate : IBkRepo
    {
        private int nxt = 1;

        public List<Book> bks = new List<Book>();

        public BookConcreate()
        {
            Add(new Book { BookName = "Harry potter", BookPrice = 12, BoookType = "Fantasy" });
            Add(new Book { BookName = "Narnia", BookPrice = 12, BoookType = "Fantasy" });
            Add(new Book { BookName = "Lord of Rings", BookPrice = 12, BoookType = "Action" });
            Add(new Book { BookName = "Ravan", BookPrice = 12, BoookType = "Mythology" });
        }

        public Book Add(Book item)
        {
            if (item == null)
            {
                throw new NotImplementedException();
            }
            item.id = nxt++;
            bks.Add(item);
            return item;


        }

        public bool Delete(int id)
        {
            bks.RemoveAll(p => p.id == id);
            return true;
        }

        public Book Get(int id)
        {
            return bks.Find(p => p.id == id); throw new NotImplementedException();
        }

        public IEnumerable<Book> GetBooks()
        {
            return bks;
        }

        public bool Update(Book item)
        {
            if (item == null)
            {
                throw new NotImplementedException();
            }
            int index = bks.FindIndex(p => p.id == item.id);
            if (index == -1)
            {
                return false;
            }

            bks.RemoveAt(index);
            bks.Add(item);
            return true;

        }
    }
}