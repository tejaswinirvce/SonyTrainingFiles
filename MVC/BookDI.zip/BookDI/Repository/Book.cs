﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BookDI.Repository
{
    public class Book
    {
        public int id { get; set; }
        public string BookName { get; set; }
        public string BoookType { get; set; }
        public decimal BookPrice { get; set; }
    }
}