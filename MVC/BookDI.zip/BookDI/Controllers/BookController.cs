﻿using BookDI.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace BookDI.Controllers
{
    public class BookController : Controller
    {
        readonly IBkRepo Repository;

        //Dependency Injection -- Injecting the Repository - decoupling
        public BookController(IBkRepo Repository)
        {
            this.Repository = Repository;

        }
        // GET: Book
        public ActionResult Index()
        {
            var books = Repository.GetBooks();
            return View(books);
        }
    }
}