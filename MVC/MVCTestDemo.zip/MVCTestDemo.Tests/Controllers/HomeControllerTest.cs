﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using MVCTestDemo;
using MVCTestDemo.Controllers;
using MVCTestDemo.Models;
using Telerik.JustMock;

namespace MVCTestDemo.Tests.Controllers
{
    [TestClass]
    public class HomeControllerTest
    {

        [TestMethod]
        public void Home_shouldReturn_AllMovies()

        {
            //Creates a mock to the Movie Model - mockmovierepo
            var mockmovierepo = Mock.Create<Repository>();

            //Arrange
            Mock.Arrange(() => mockmovierepo.GetMovies()).
                  Returns(new List<Movie>()
                  {
                    new Movie{MName="IT",Mstar="somestar",BOColl=3000,id=1},
                    new Movie{MName="Us",Mstar="Hugh",BOColl=3000,id=2},
                    new Movie{MName="Train to Busan",Mstar="hugh",BOColl=3000,id=3}
              }).MustBeCalled();



            //Act
            HomeController obj = new HomeController(mockmovierepo);
            ViewResult vw = obj.Index() as ViewResult;
            var model = vw.Model as IEnumerable<Movie>;

            //Assert 
            Assert.AreEqual("HUGH",model.ToList()[2].Mstar,ignoreCase:true );


        }





        [TestMethod]
        public void Index()
        {
            // Arrange
            HomeController controller = new HomeController();

            // Act
            ViewResult result = controller.Index();

            // Assert
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void About()
        {
            // Arrange
            HomeController controller = new HomeController();

            // Act
            ViewResult result = controller.About() as ViewResult;

            // Assert
            Assert.AreEqual("Your application description page.", result.ViewBag.Message);
        }

        [TestMethod]
        public void Contact()
        {
            // Arrange
            HomeController controller = new HomeController();

            // Act
            ViewResult result = controller.Contact() as ViewResult;

            // Assert
            Assert.IsNotNull(result);
        }
    }
}
