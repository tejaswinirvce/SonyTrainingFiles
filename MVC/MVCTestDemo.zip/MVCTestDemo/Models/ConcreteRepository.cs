﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCTestDemo.Models
{
    public class ConcreteRepository : Repository
    {
        public List<Movie> GetMovies()
        {
            return new List<Movie>()
            {
                new Movie{id=1,MName="IT",Mstar="Jack",BOColl=10000,MGenre="Horror"},
                new Movie{id=1,MName="Us",Mstar="Hugh",BOColl=10000,MGenre="Horror"},
                new Movie{id=1,MName="Annabelle",Mstar="Tom",BOColl=10000,MGenre="Horror"},
                new Movie{id=1,MName="Get Out",Mstar="Russel",BOColl=10000,MGenre="Horror"},
                new Movie{id=1,MName="Train to Busan",Mstar="Brad",BOColl=10000,MGenre="Horror"},
            };
        }
    }
}