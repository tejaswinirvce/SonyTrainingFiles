﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCTestDemo.Models
{

    public class Movie
    {
        public int id { get; set; }
        public string MName { get; set; }
        public string Mstar { get; set; }
        public int BOColl { get; set; }
        public string MGenre { get; set; }
    }
}