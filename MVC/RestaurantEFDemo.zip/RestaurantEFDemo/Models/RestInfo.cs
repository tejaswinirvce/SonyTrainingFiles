﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RestaurantEFDemo.Models
{
    public class RestInfo
    {

        public int id { get; set; }
        public int Rating { get; set; }
        public string ReviewBody { get; set; }
        public int RestaurantId { get; set; }
        public string Reviewer { get; set; }

    }
}