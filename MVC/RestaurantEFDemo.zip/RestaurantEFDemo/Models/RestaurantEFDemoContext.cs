﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace RestaurantEFDemo.Models
{
    public class RestaurantEFDemoContext : DbContext
    {
     
        public RestaurantEFDemoContext() : base("name=RestaurantEFDemoContext")
        {
        }

        public DbSet<RestModel> RestModels { get; set; }
        public DbSet<RestInfo> Reviews { get; set; }
    }
}
