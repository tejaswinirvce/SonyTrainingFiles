﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RestaurantEFDemo.Models
{
    public class RestModel
    {
        public int id { get; set; }
        public string Rname { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Country { get; set; }
        public virtual ICollection<RestInfo> Reviews { get; set; }

    }
}