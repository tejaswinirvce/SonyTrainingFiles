﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using RestaurantEFDemo.Models;

namespace RestaurantEFDemo.Controllers
{
    public class RestInfoesController : Controller
    {
        private RestaurantEFDemoContext db = new RestaurantEFDemoContext();

        // GET: RestInfoes
        public ActionResult Index([Bind(Prefix ="id")] int RestaurantId)
        {
            var restaurant = db.RestModels.Find(RestaurantId);
            if (restaurant != null)
            {
                return View(restaurant);
            }
            return HttpNotFound();
        }
        

        // GET: RestInfoes/Create
        public ActionResult Create(int RestaurantId)
        {
            return View();
        }

        // POST: RestInfoes/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(RestInfo restInfo)
        {
            if (ModelState.IsValid)
            {
                db.Reviews.Add(restInfo);
                db.SaveChanges();
                return RedirectToAction("Index", new { id = restInfo.RestaurantId });
            }

            return View(restInfo);
        }

        // GET: RestInfoes/Edit/5
        public ActionResult Edit(int? id)
        {
            
            RestInfo restInfo = db.Reviews.Find(id);
            
            return View(restInfo);
        }

        // POST: RestInfoes/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(RestInfo restInfo)
        {
            if (ModelState.IsValid)
            {
                db.Entry(restInfo).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index",new { id=restInfo.RestaurantId});
            }
            return View(restInfo);
        }

        // GET: RestInfoes/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            RestInfo restInfo = db.Reviews.Find(id);
            if (restInfo == null)
            {
                return HttpNotFound();
            }
            return View(restInfo);
        }

        // POST: RestInfoes/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            RestInfo restInfo = db.Reviews.Find(id);
            db.Reviews.Remove(restInfo);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
