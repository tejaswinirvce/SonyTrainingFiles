namespace RestaurantEFDemo.Migrations
{
    using System;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;

    internal sealed class Configuration : DbMigrationsConfiguration<RestaurantEFDemo.Models.RestaurantEFDemoContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = true;
            ContextKey = "RestaurantEFDemo.Models.RestaurantEFDemoContext";
        }

        protected override void Seed(Models.RestaurantEFDemoContext context)
        {
            //  This method will be called after migrating to the latest version.
           
            //  You can use the DbSet<T>.AddOrUpdate() helper extension method 
            //  to avoid creating duplicate seed data. E.g.
            //
            context.RestModels.AddOrUpdate(
              p => p.Rname,
              new Models.RestModel { Rname = "Eden" },
              new Models.RestModel { Rname = "Cafe Cofee Day" },
              new Models.RestModel { Rname = "Udupi" }
            );
            //
        }
    }
}
