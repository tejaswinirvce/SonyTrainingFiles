namespace RestaurantEFDemo.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class InitialCreate : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.RestModels",
                c => new
                    {
                        id = c.Int(nullable: false, identity: true),
                        Rname = c.String(),
                        City = c.String(),
                        State = c.String(),
                        Country = c.String(),
                    })
                .PrimaryKey(t => t.id);
            
            CreateTable(
                "dbo.RestInfoes",
                c => new
                    {
                        id = c.Int(nullable: false, identity: true),
                        Rating = c.Int(nullable: false),
                        ReviewBody = c.String(),
                        RestaurantId = c.Int(nullable: false),
                        Reviewer = c.String(),
                        RestModel_id = c.Int(),
                    })
                .PrimaryKey(t => t.id)
                .ForeignKey("dbo.RestModels", t => t.RestModel_id)
                .Index(t => t.RestModel_id);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.RestInfoes", "RestModel_id", "dbo.RestModels");
            DropIndex("dbo.RestInfoes", new[] { "RestModel_id" });
            DropTable("dbo.RestInfoes");
            DropTable("dbo.RestModels");
        }
    }
}
