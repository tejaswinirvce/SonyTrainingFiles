﻿using SonyModelProject2.Models;
using SonyModelProject2.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SonyModelProject2.Controllers
{
    public class ActorController : Controller
    {
        
       
        public ActionResult Welcome(string AName,string AIndustry)
        {
            Actors act1 = new Actors { ActorName = AName, ActorIndustry = AIndustry };
            return View(act1);
        }

        // GET: Actor
        [MyLogFilter]
        public ActionResult Index()
        {
            var actors = from m in act
                         orderby m.ActorName
                         select m;
            
            return View(actors);
        }

        // GET: Actor/Details/5
        public ActionResult Details(int id)
        {

            var vw = act.Single(m => m.id == id);

            return View(vw);

        }

        // GET: Actor/Create
        public ActionResult Create()
        {
            Actors actors = new Actors();
            return View(actors);
        }

        // POST: Actor/Create
        [HttpPost]
        public ActionResult Create(Actors actors,FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here
                act.Add(actors);

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Actor/Edit/5
        
        public ActionResult Edit(int id)
        {

            var vw = act.Single(m => m.id == id);

            return View(vw);
        }

        // POST: Actor/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
              
            // TODO: Add update logic here
                var vw = act.Single(m => m.id == id);

               
                    if(TryUpdateModel(vw))
                { 
                    return RedirectToAction("Index");
                }
           
                return View(vw);
            
        }

        // GET: Actor/Delete/5
        public ActionResult Delete(int id)
        {
            var vw = act.Find(m => m.id == id);
            return View(vw);
        }

        // POST: Actor/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here
                var vw = act.Find(m => m.id == id);

                act.Remove(vw);
                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        //DB Collection
        static List<Actors> act = new List<Actors>()
        {
            new Actors
            {
                id = 1,
                ActorName = "Di Caprio",
                ActorIndustry="Hollywood",
                Age = 40


            },
            new Actors

            {
                id = 2,
                ActorName = "Tom Hanks",
                ActorIndustry="Hollywood",
                Age = 50


            },

            new Actors

            {
                id = 3,
                ActorName = "Hugh Jackson",
                ActorIndustry="Hollywood",
                Age = 50


            },

        new Actors

            {
                id = 4,
                ActorName = "Scarlett Johanson",
                ActorIndustry="Hollywood",
                Age = 30


            },

        };


    }
}
