﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SonyModelProject2.Controllers
{
    public class TempFirstController : Controller
    {
        // GET: TempFirst
        public ActionResult Index()
        {
            TempData["data"] = "Temporary data from first controller";
            return new RedirectResult(@"~\Second\");
        }
    }
}