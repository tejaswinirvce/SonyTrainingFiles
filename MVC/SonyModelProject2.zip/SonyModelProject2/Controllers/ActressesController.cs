﻿using SonyModelProject2.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SonyModelProject2.Controllers
{
    public class ActressesController : Controller
    {
        //DB Collection
        static List<Actress> act = new List<Actress>()
        {
            new Actress
            {
                id = 1,
                ActressName = "Emma watson",
                Industry="Hollywood",
                Country="USA",
                Age = 20


            },
            new Actress

            {
                id = 2,
                ActressName = "Gwyneth Paltrow",
                Industry="Hollywood",
                Age = 50,
                Country="USA"


            },

            new Actress

            {
                id = 3,
                ActressName = "Shradda",
                Industry="Sandalwood",
                Age = 20,
                Country="India"


            },

        new Actress

            {
                id = 4,
                ActressName = "Scarlett Johanson",
                Industry="Hollywood",
                Age = 30,
                Country="USA"


            },

        };

        // GET: Actresses
        public ActionResult Index()
        {
            var actors = from m in act
                         orderby m.ActressName
                         select m;

            return View(actors);
            
        }

        // GET: Actresses/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: Actresses/Create
        public ActionResult Create()
        {
            Actress actress = new Actress();
            return View(actress);
            
        }

        // POST: Actresses/Create
        [HttpPost]
        public ActionResult Create(Actress actress,FormCollection collection)
        {
                // TODO: Add insert logic here
                if (ModelState.IsValid)
                {
                    act.Add(actress);
                    
                    return RedirectToAction("Index");
                }
            
                return View();
           
        }

        // GET: Actresses/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: Actresses/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Actresses/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: Actresses/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
