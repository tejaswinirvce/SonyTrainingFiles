﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SonyModelProject2.Controllers
{
    public class ReturnDemosController : Controller
    {
        // GET: ReturnDemos
        //View page - html
        public ViewResult Index()
        {
            return View();
        }

    

        //Redirecting to another action
        public RedirectResult Redirecting()
        {
            return Redirect("Index");
        }

        //Returning a partial view
        public PartialViewResult Page2()
        {
            return Page2();
        }

        //string - content
        public ContentResult Mycontent()
        {

            return Content("A basic content ");
        }

        //Json return for EMp obj
        public JsonResult MyEmp()
        {
            emp e1 = new emp { empid = 1, empname = "Aparajit" };
            return Json(e1, JsonRequestBehavior.AllowGet);

        }




    }

    class emp
        {
        public int empid { get; set; }
        public string empname { get; set; }
    }

}