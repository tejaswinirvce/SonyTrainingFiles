﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SonyModelProject2.Filters
{
    public class MyLogFilter:ActionFilterAttribute
    {
        public override void OnActionExecuted(ActionExecutedContext filterContext)
        {
            var vb = filterContext.Controller.ViewBag;
            var ctr = filterContext.RouteData.Values["Controller"];
            var act = filterContext.RouteData.Values["Action"];
            var data = $"The Data passed during routing {ctr}, {vb},{act} ";
            Debug.WriteLine("Action Executed .. here are the log! " + data);
            base.OnActionExecuted(filterContext);
        }

        public override void OnResultExecuting(ResultExecutingContext filterContext)
        {
            filterContext.Controller.ViewBag.msg = "Hello dear..";
            base.OnResultExecuting(filterContext);
        }



    }
}