﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace SonyModelProject2.Models
{
    public class maxwordsAttribute : ValidationAttribute
    {
     

        public maxwordsAttribute(int maxwords):base("{0} has too many words")
        {

            _maxwords = maxwords;
        }

        public override bool IsValid(object value)
        {
            return base.IsValid(value);
        }

        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if (value != null)
            {
                var str = value.ToString();
                if (str.Split(' ').Length > _maxwords)
                {
                    var errorMessage = FormatErrorMessage(validationContext.DisplayName);
                    return new ValidationResult(errorMessage);
                }
            }
            return ValidationResult.Success;
        }


        private readonly int _maxwords;
    }


    public class Actress:IValidatableObject
    {
       
        public int id { get; set; }
        [Required]
        [MaxLength(5)]
        [DataType(DataType.Text)]
        public string ActressName { get; set; }

        [Required]
        public string Industry { get; set; }

        [Required]
        [Display(Name ="Country of Birth")]
        [maxwords(2)]      
        public string Country { get; set; }
        [Required]
     
        public int Age { get; set; }

        public IEnumerable<ValidationResult> Validate(ValidationContext validationContext)
        {
            if(Age > 60 && Country.ToLower().StartsWith("china"))
            {
                yield return new ValidationResult("Sorry! No Oldies from China");
            }
           
        }
    }



}