﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace SonyModelProject2.Models
{
    public class Actors
    {
        public int id { get; set; }
        [Required]
        [MaxLength(10)]
        public string ActorName { get; set; }
        [RegularExpression("[a-d]")]
        public string ActorIndustry { get; set; }
        public int Age { get; set; }
    }
}