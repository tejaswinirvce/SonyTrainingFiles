﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SonyModelProject2.Helpers
{
    public static class MyHelper
    {
        public static IHtmlString CreateLabel(string Content)
        {
            string lblstr =$"<label style=\"background-color:seagreen;color:darkblue;font-size:24px\">{Content}</label>";

            return new HtmlString(lblstr);
        }

        public static MvcHtmlString GenerateLabel( this HtmlHelper helper,string Content)
        {
            string lblstr = $"<label style=\"border:solid 1px grey;padding:3px;text-shadow:3px 3px 3px darkgray;border-radius:5px;background-color:lightcoral;color:darkblue;font-size:24px\">{Content}</label>";
            return new MvcHtmlString(lblstr);
        }
    }
}